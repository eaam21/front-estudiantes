export interface TipoDocumento{
    idDocumento: number,
    descripcion: string
}