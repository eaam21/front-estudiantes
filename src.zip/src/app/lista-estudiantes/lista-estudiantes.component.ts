import { Component, inject } from '@angular/core';
import { MatToolbar } from '@angular/material/toolbar';
import {MatButtonModule} from '@angular/material/button';
import {MatTooltipModule} from '@angular/material/tooltip';
import {MatIconModule} from '@angular/material/icon';
import {MatTableDataSource, MatTableModule} from '@angular/material/table';
import { EstudianteService } from '../services/estudiante.service';
import { Estudiante } from '../model/estudiante.interface';
@Component({
  selector: 'app-lista-estudiantes',
  standalone: true,
  imports: [MatToolbar, MatButtonModule, MatTooltipModule, MatIconModule, MatTableModule],
  templateUrl: './lista-estudiantes.component.html',
  styleUrl: './lista-estudiantes.component.css'
})
export class ListaEstudiantesComponent {
  private estudianteService = inject(EstudianteService)
  
  //listaEstudiantes: Estudiante[]=[]
  dataSource:any
  columnas: string[]=['idEstudiante', 'apellidoPaterno', 'apellidoMaterno', 'nombres']

  ngOnInit():void{
    this.estudianteService.listar().subscribe(
      (respuesta)=>{
        console.log(respuesta)
        this.dataSource = new MatTableDataSource<Estudiante>(respuesta);
      }
    )
  }

}
