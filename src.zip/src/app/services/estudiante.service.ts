import { HttpClient } from '@angular/common/http';
import { Injectable, inject } from '@angular/core';
import { Estudiante } from '../model/estudiante.interface';

@Injectable({
  providedIn: 'root'
})
export class EstudianteService {
  private http = inject(HttpClient)

  constructor() { }
  
  listar(){
    return this.http.get<Estudiante[]>('http://localhost:8080/api/estudiante/listar')
  }
}
